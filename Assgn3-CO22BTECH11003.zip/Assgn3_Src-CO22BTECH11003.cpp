#include <iostream>
#include <fstream>
#include <vector>
#include <thread>
#include <atomic>
#include <chrono>
#include <algorithm>

using namespace std;

const int Max = 8192;

// Global variables
int N, K, rowInc;
int A[Max][Max];
int ans[Max][Max];
atomic<int> C(0);
atomic_flag lock = ATOMIC_FLAG_INIT;
atomic<bool> lock1(false);
atomic<bool> waiting(false);

// Function to initialize matrix to zero
void initializeMatrix() {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            ans[i][j] = 0;
        }
    }
}

// Function to perform matrix multiplication for a subset of rows
void multiplyRows(int startRow, int endRow) {
    for (int m = startRow; m < endRow && m < N; ++m) {
        for (int n = 0; n < N; ++n) {
            int sum = 0;
            for (int i = 0; i < N; ++i) {
                sum += A[m][i] * A[i][n];
            }
            ans[m][n] = sum;
        }
    }
}

// Function for TAS mutual exclusion
void* matrixMultiplicationTAS(void* arg) {
    int start, end;
    while (true) {
        if (!lock.test_and_set(std::memory_order_acquire)) {
            start = C;
            C += rowInc;
            end = min(C.load(), N);
            lock.clear(std::memory_order_release);
            break;
        }
    }
    multiplyRows(start, end);
    pthread_exit(NULL);
}

// Function for CAS mutual exclusion
void* matrixMultiplicationCAS(void* arg) {
    int start, end;
    while (true) {
        bool expected = false;
        if (lock1.compare_exchange_weak(expected, true, std::memory_order_acquire)) {
            start = C;
            C += rowInc;
            end = min(C.load(), N);
            lock1.store(false, std::memory_order_release);
            break;
        }
    }
    multiplyRows(start, end);
    pthread_exit(NULL);
}


// Function for Bounded CAS mutual exclusion
void* matrixMultiplicationBCAS(void* arg) {
    int start, end;
    int i = *static_cast<int*>(arg);
    bool key = true;
    waiting.store(true);
    while (waiting.load() && key) {
        bool expected = false;
        if (lock1.compare_exchange_weak(expected, true, memory_order_acquire)) {
            key = false;
        }
    }
    waiting.store(false);
    start = C;
    C += rowInc;
    end = min(C.load(), N);
    multiplyRows(start, end);
    //cout << start << " "<<  end << endl;
    int j = (i + 1) % N;
    while (j != i && !waiting.load()) {
        j = (j + 1) % N;
    }
    if (j == i) {
        lock1 = false;
    } else {
        waiting.store(false);
    }
    return nullptr; 
}


// Function for atomic increment
void* matrixMultiplicationAtomic(void* arg) {
    int start = C.fetch_add(rowInc, std::memory_order_relaxed);
    int end = min(start + rowInc, N);
    multiplyRows(start, end);
    pthread_exit(NULL);
}

// Function to measure time taken for matrix multiplication
double measureTime(void* (*func)(void*)) {
    auto start = chrono::high_resolution_clock::now();
    vector<thread> threads(K);
    for (int i = 0; i < K; ++i) {
        threads[i] = thread(func, static_cast<void*>(&i));
    }
    for (auto& t : threads) {
        t.join();
    }
    auto end = chrono::high_resolution_clock::now();
    double duration = chrono::duration_cast<chrono::milliseconds>(end - start).count() / 1000.0;
    cout << duration << endl;
    return duration;
}

// Function to write matrix to file
void printMatrixToFile(int matrix[Max][Max], ofstream& outfile) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            outfile << matrix[i][j] << " ";
        }
        outfile << endl;
    }
}

int main() {
    // Read input from file
    ifstream infile("inp.txt");
    if (!infile) {
        cerr << "Error: Unable to open input file." << endl;
        return 1;
    }
    infile >> N >> K >> rowInc;
    cout << N << " " << K << " " << rowInc << endl;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            infile >> A[i][j];
        }
    }
    infile.close();

    // Output files
    ofstream outfileTAS("out_TAS.txt");
    ofstream outfileCAS("out_CAS.txt");
    ofstream outfileBCAS("out_BoundedCAS.txt");
    ofstream outfileAtomic("out_AtomicIncrement.txt");

    if (!outfileTAS || !outfileCAS || !outfileBCAS || !outfileAtomic) {
        cerr << "Error: Unable to open output file." << endl;
        return 1;
    }

    // Measure time and perform matrix multiplication with different mutual exclusion methods
    initializeMatrix();
    double timeTAS = measureTime(matrixMultiplicationTAS);
    outfileTAS << "Time (s): " << timeTAS << endl;
    outfileTAS << "Resultant Matrix:" << endl;
    printMatrixToFile(ans, outfileTAS);
 
    initializeMatrix();
    C.store(0);
    double timeCAS = measureTime(matrixMultiplicationCAS);
    outfileCAS << "Time (s): " << timeCAS << endl;
    outfileCAS << "Resultant Matrix:" << endl;
    printMatrixToFile(ans, outfileCAS);

    initializeMatrix();
    C.store(0);
    lock1 = false;
    double timeBCAS = measureTime(matrixMultiplicationBCAS);
    outfileBCAS << "Time (s): " << timeBCAS << endl;
    outfileBCAS << "Resultant Matrix:" << endl;
    printMatrixToFile(ans, outfileBCAS);

    initializeMatrix();
    C.store(0);
    double timeAtomic = measureTime(matrixMultiplicationAtomic);
    outfileAtomic << "Time (s): " << timeAtomic << endl;
    outfileAtomic << "Resultant Matrix:" << endl;
    printMatrixToFile(ans, outfileAtomic); 

    // Close output files
    outfileTAS.close();
    outfileCAS.close();
    outfileBCAS.close();
    outfileAtomic.close();

    return 0;
}
