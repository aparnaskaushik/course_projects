Assignment 3 Execution Instructions

Submitted Files:

    Source code file: Assgn3_Src-CO22BTECH11003.cpp
    README file: Assgn3_ReadMe-CO22BTECH11003.txt
    Sample input file: inp.txt
    Report: Assgn3_Report-CO22BTECH11003.pdf

Instructions:

    Input File (inp.txt):
        The program expects input parameters from the inp.txt file located in the same directory as the source code.
        Ensure inp.txt contains the following parameters in the specified order:
            Matrix size (N)
            Number of threads (K)
            Row increment (rowInc)
            Matrix elements for input matrix A (N x N)

    Compile the Source Code:
        Ensure you have a C++ compiler installed on your system.
        Open a terminal or command prompt.
        Navigate to the directory containing the source code file.
        Compile the code using the following command:

    g++ Assgn3_Src-CO22BTECH11003.cpp -o matrix_mult

Run the Executable:

    After successful compilation, execute the compiled program by running the following command:

        ./matrix_mult

    Output Files:
        The program generates multiple output files based on the mutual exclusion methods used:
            out_TAS.txt: Output file for TAS mutual exclusion method
            out_CAS.txt: Output file for CAS mutual exclusion method
            out_BoundedCAS.txt: Output file for Bounded CAS mutual exclusion method
            out_AtomicIncrement.txt: Output file for Atomic mutual exclusion method
        Each output file contains the execution time in seconds and the resultant matrix.

    Viewing Results:
        Results are printed as output in the terminal.
        In the order TAS,CAS,BCAS and Atomic.
        Alternatively, open the generated output files using a text editor to view the results.

    Cleaning Up:
        After viewing the results, you can delete the compiled executable and output files if desired.

Note:

    Ensure the input parameters in inp.txt are correctly set according to the experiment requirements.
    This program uses the pthread library for multithreading. Make sure your system supports pthreads and the necessary libraries are linked during compilation.
