#include<stdio.h>
int main(void){
	float A[400][400];
	float B[400][1];
	float X[400][1];
	FILE *pointer;
	FILE *p;
	// opening input files
	pointer=fopen("A.txt","r"); 
	p=fopen("B.txt","r"); 
	// checking if file opened
	if (pointer == NULL || p==NULL){
		printf("Failed to open file.\n");
        	return 1;}
        //extracting matrixes from input files
	for(int i=0;i<400;i++){
		fscanf(p,"%f",&B[i][0]);
		for(int j=0;j<400;j++){
			fscanf(pointer,"%f ",&A[i][j]);}}
	fclose(pointer);
	fclose(p);
	// generating L and U matrix
	float L[400][400];
	float U[400][400];
	float sum;
	for(int i=0;i<400;i++){
		L[i][i]=1;}
	for (int j=0;j<400;j++){
		for(int i=0;i<=j;i++){
			if (i<j){
				L[i][j]=0;}
			sum=0;
			for(int k=0;k<i;k++){
				sum=sum+L[i][k]*U[k][j];}
			U[i][j]=A[i][j]-sum;}
		for(int i=j+1;i<400;i++){
			U[i][j]=0;
			sum=0;
			for(int k=0;k<j;k++){
				sum=sum+L[i][k]*U[k][j];}
			L[i][j]=(A[i][j]-sum)/U[j][j];}}
	// forward substitution
	for(int k=0;k<399;k++){
		for(int i=k+1;i<400;i++){
			float m=L[i][k]/L[k][k];
			for(int j=k+1;j<400;j++){
				L[i][j]=L[i][j]-m*L[k][j];}
			B[i][0]=B[i][0]-m*B[k][0];}}
	// backward substitution
	X[399][0]=B[399][0]/U[399][399];
	for(int i=398;i>=0;i--){
		sum=0;
		for(int j=i+1;j<400;j++){
			sum=sum+U[i][j]*X[j][0];}
		X[i][0]=(B[i][0]-sum)/U[i][i];}
	// creating T from the solution
	float T[22][22];
	for (int i=0;i<22;i++){
		T[0][i]=30;
		T[21][i]=100;
		T[i][0]=30;
		T[i][21]=30;}
	T[21][0]=T[21][21]=65;
	for(int k=0;k<400;k++){
		int i=k/20;
		int j=k-20*i;
		T[i+1][j+1]=X[k][0];}
	FILE *f;
	// opening output files 
	f=fopen("output_LU.txt","w"); 
	// checking if file opened
	if (f==NULL){
		printf("Failed to open file.\n");
        	return 1;}
	fputs("The temperature of nodes are:\n",f);
	for(int i=0;i<22;i++){
		for(int j=0;j<22;j++){
			fprintf(f,"%f ",T[i][j]);}
			fputs("\n",f);}
	fclose(f);
}
