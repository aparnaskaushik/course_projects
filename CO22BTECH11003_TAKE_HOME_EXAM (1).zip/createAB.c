#include<stdio.h>
int k(int i,int j){
	int k=20*i+j;
	return k;}
int main(void){
	float A[400][400]={0};
	float B[400][1]={0};
	for(int i=0;i<20;i++){
		for(int j=0;j<20;j++){
			A[20*i+j][k(i,j)]=4;
			if(i-1>=0){A[20*i+j][k(i-1,j)]=-1;}
			if(j-1>=0){A[20*i+j][k(i,j-1)]=-1;}
			if(i+1<20){A[20*i+j][k(i+1,j)]=-1;}
			if(j+1<20){A[20*i+j][k(i,j+1)]=-1;}
			if (i==0||j==0||j==19){B[20*i+j][0]=30;}
			if (i==19){B[20*i+j][0]=100;}
			if (i==0&&j==0||i==0&&j==19||i==19&&j==0||i==19&&j==19){B[20*i+j][0]=65;}}}
	for(int i=0;i<20;i++){
		for(int j=0;j<20;j++){
		B[20*i+j][0]=B[20*i+j][0]+(10-i)*(10-i)+(j-10)*(j-10);}}
	FILE *pointer;
	FILE *p;
	// opening input files
	pointer=fopen("A.txt","w"); 
	p=fopen("B.txt","w"); 
	// checking if file opened
	if (pointer == NULL || p==NULL){
		printf("Failed to open file.\n");
        	return 1;}
	for(int i=0;i<400;i++){
		fprintf(p,"%f ",B[i][0]);
		for(int j=0;j<400;j++){
			fprintf(pointer,"%f ",A[i][j]);}
		fputs("\n",pointer);
		fputs("\n",p);}
	fclose(pointer);
	fclose(p);
}
