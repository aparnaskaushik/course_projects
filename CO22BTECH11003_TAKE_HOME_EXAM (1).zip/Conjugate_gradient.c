#include<stdio.h>
int main(void){
	float A[400][400];
	float B[400][1];
	float X[400][1];
	FILE *pointer;
	FILE *p;
	// opening input files
	pointer=fopen("A.txt","r"); 
	p=fopen("B.txt","r"); 
	// checking if file opened
	if (pointer == NULL || p==NULL){
		printf("Failed to open file.\n");
        	return 1;}
	for(int i=0;i<400;i++){
		fscanf(p,"%f",&B[i][0]);
		for(int j=0;j<400;j++){
			fscanf(pointer,"%f ",&A[i][j]);}}
	fclose(pointer);
	fclose(p);
	for(int i=0;i<400;i++){
		X[i][0]=700;}
	float r[400][1];
	for(int i=0;i<400;i++){
		r[i][0]=B[i][0];
		for(int j=0;j<400;j++){
			r[i][0]=r[i][0]-A[i][j]*X[j][0];}}
	float d[400][1];
	for(int i=0;i<400;i++){
		d[i][0]=r[i][0];}
	float s=0;
	for(int i=0;i<400;i++){
		s=s+r[i][0]*r[i][0];}
	int count=0;
	float alpha,beta;
	float a,b;
	float g[400][1];
	while (s>0.001){
		for(int i=0;i<400;i++){
		        g[i][0]=0;
			for(int j=0;j<400;j++){
				g[i][0]=g[i][0]+A[i][j]*d[j][0];}}
	        a=0,b=0;
		for(int i=0;i<400;i++){
			a=a+r[i][0]*d[i][0];
			b=b+d[i][0]*g[i][0];}
		alpha=a/b;
		for(int i=0;i<400;i++){
			X[i][0]=X[i][0]+alpha*d[i][0];}
		for(int i=0;i<400;i++){
			for(int j=0;j<400;j++){
				r[i][0]=r[i][0]-alpha*A[i][j]*d[j][0];}}
		a=0;b=0;
		for(int i=0;i<400;i++){
			a=a+r[i][0]*g[i][0];
			b=b+d[i][0]*g[i][0];}
		beta=-a/b;
		for(int i=0;i<400;i++){
			d[i][0]=r[i][0]+beta*d[i][0];}
		s=0;
		for(int i=0;i<400;i++){
			s=s+r[i][0]*r[i][0];}
		count=count+1;}
	// creating T from the solution
	float T[22][22];
	for (int i=0;i<22;i++){
		T[0][i]=30;
		T[21][i]=100;
		T[i][0]=30;
		T[i][21]=30;}
	T[21][0]=T[21][21]=65;
	for(int k=0;k<400;k++){
		int i=k/20;
		int j=k-20*i;
		T[i+1][j+1]=X[k][0];}
	FILE *f;
	// opening output files 
	f=fopen("output_CG.txt","w"); 
	// checking if file opened
	if (f==NULL){
		printf("Failed to open file.\n");
        	return 1;}
        fprintf(f,"Got this answer in %d iterations\n",count);
	fputs("The temperature of nodes are:\n",f);
	for(int i=0;i<22;i++){
		for(int j=0;j<22;j++){
			fprintf(f,"%f ",T[i][j]);}
			fputs("\n",f);}
	fclose(f);
}
