Assignment 4 Execution Instructions

Submitted Files:

    Source code file: rw_frw-CO22BTECH11003.cpp
    README file: Assgn4_ReadMe-CO22BTECH11003.txt
    Sample input file: inp-params.txt
    Report: Assgn4_Report-CO22BTECH11003.pdf

Instructions:

    Input File (inp-params.txt):
        The program expects input parameters from the inp-params.txt file located in the same directory as the source code.
        Ensure inp-params.txt contains the following parameters in the specified order:
            nw: the number of writer threads
            nr: the number of reader threads
            kw: the number of times each writer thread tries to enter the CS
            kr: the number of times each reader thread tries to enter the CS
            μCS: average milliseconds spent in the critical section
            μRem: average milliseconds spent in the reminder section

    Compile the Source Code:
        Ensure you have a C++ compiler installed on your system.
        Open a terminal or command prompt.
        Navigate to the directory containing the source code file.
        Compile the code using the following command:

    g++ rw_frw-CO22BTECH11003.cpp -o rw_frw

Run the Executable:

    After successful compilation, execute the compiled program by running the following command:

        ./rw_frw

    Output Files:
        The program generates multiple output files based on the program:
            RW-log.txt: Output file of the log of all the events for the reader-writer (writer preference)
            FairRW-log.txt: Output file of the log of all the events for the fair reader-writer
            AverageTime.txt: Output file of average time taken by reader and writer threads to enter critical section for both the algorithm

    Viewing Results:
        In the terminal, as the reader or writer threads completes executing all the number of times it has to execute, it prints that ot finished.
        To view exact log, open the RW-log.txt and FairRW-log.txt for reader-writer(writer preference) and fair reader-writer algorithm respectively.
        To view Average time taken by the different threads to enter the critical section open the AverageTime.txt file.

    Cleaning Up:
        After viewing the results, you can delete the compiled executable and output files if desired.

Note:

    Ensure the input parameters in inp-params.txt are correctly set according to the experiment requirements.
    This program uses the thread library for multithreading. Make sure your system supports threads and the necessary libraries are linked during compilation.
