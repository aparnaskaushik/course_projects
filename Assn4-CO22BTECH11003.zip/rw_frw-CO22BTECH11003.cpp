#include <iostream>
#include <thread>
#include <mutex>
#include <fstream>
#include <vector>
#include <chrono>
#include <random>
#include <semaphore.h>

using namespace std;
using namespace chrono;

ofstream rw_log_file, fair_rw_log_file, avg_time_file;
vector<double> writer_entry_times, reader_entry_times;
vector<double> fair_writer_entry_times, fair_reader_entry_times;

// Define mutexes for protecting vector access
mutex writer_entry_mutex;
mutex reader_entry_mutex;
mutex fair_writer_entry_mutex;
mutex fair_reader_entry_mutex;

// Define constants for input parameters
int nw, nr, kw, kr;
double muCS, muRem;

// Define semaphores and mutex
sem_t rw_mutex, read_write_mutex, writer_inside_mutex;
int read_count = 0;
int writer_waiting = 0; // Track whether a writer is waiting
bool writer_inside = false; // Track whether a writer is currently inside the critical section

// Function to get system time
string getSysTime() {
    auto now = chrono::system_clock::now();
    time_t now_c = chrono::system_clock::to_time_t(now);
    return ctime(&now_c);
}

// Function to generate exponentially distributed random numbers
double exp_distribution(double mean) {
    random_device rd;
    mt19937 gen(rd());
    exponential_distribution<double> distribution(1.0 / mean);
    return distribution(gen);
}

// Writer function
void writer(int id) {
    for (int i = 0; i <= kw; i++) {
        auto start = high_resolution_clock::now();
        string reqTime = getSysTime();
        rw_log_file << i << "th CS request by Writer Thread " << id << " at " << reqTime;
        writer_waiting++;
        // Wait until no readers or writers are inside the CS
        sem_wait(&read_write_mutex);
        sem_wait(&writer_inside_mutex);
        while (read_count > 0 || writer_inside) {
            sem_post(&writer_inside_mutex);
            sem_post(&read_write_mutex);
            this_thread::sleep_for(chrono::milliseconds(10)); // Sleep to avoid busy-waiting
            sem_wait(&read_write_mutex);
            sem_wait(&writer_inside_mutex);
        }

        // Now the writer can enter the CS
        writer_inside = true;
        writer_waiting--;
        sem_post(&writer_inside_mutex);

        // Reset writer_waiting when the writer gains access
        sem_post(&read_write_mutex);

        string enterTime = getSysTime();
        rw_log_file << i << "th CS Entry by Writer Thread " << id << " at " << enterTime;

        // Simulate writing in CS
        int muCStime = exp_distribution(muCS);
        this_thread::sleep_for(chrono::milliseconds(muCStime));

        // Exit CS
        sem_wait(&writer_inside_mutex);
        writer_inside = false;
        sem_post(&writer_inside_mutex);

        string exitTime = getSysTime();
        rw_log_file << i << "th CS Exit by Writer Thread " << id << " at " << exitTime;
        auto end = high_resolution_clock::now();
        auto duration = duration_cast<milliseconds>(end - start);
        lock_guard<mutex> lock(writer_entry_mutex);
        writer_entry_times.push_back(duration.count()/1e3);

        // Simulate executing in Remainder Section
        this_thread::sleep_for(chrono::milliseconds((int)exp_distribution(muRem)));
    }
    cout << id << " Writer finished" << endl;
}

// Reader function
void reader(int id) {
    for (int i = 0; i < kr; i++) {
        auto start = high_resolution_clock::now();
        string reqTime = getSysTime();
        rw_log_file << i << "th CS request by Reader Thread " << id << " at " << reqTime;

        // Wait until no writers are waiting or in the critical section
        sem_wait(&read_write_mutex);
        while (writer_waiting || writer_inside) {
            sem_post(&read_write_mutex);
            // Sleep for a short duration to avoid busy-waiting
            this_thread::sleep_for(chrono::milliseconds(10));
            sem_wait(&read_write_mutex);
        }
        read_count++;
        sem_post(&read_write_mutex);

        string enterTime = getSysTime();
        rw_log_file << i << "th CS Entry by Reader Thread " << id << " at " << enterTime;

        // Simulate reading from CS
        int muCStime = exp_distribution(muCS);
        this_thread::sleep_for(chrono::milliseconds(muCStime));

        sem_wait(&read_write_mutex);
        read_count--;
        if (read_count == 0)
            sem_post(&rw_mutex);
        sem_post(&read_write_mutex);
        auto end = high_resolution_clock::now();
        auto duration = duration_cast<milliseconds>(end - start);
        lock_guard<mutex> lock(reader_entry_mutex);
        reader_entry_times.push_back(duration.count()/1e3);

        // Simulate executing in Remainder Section
        string exitTime = getSysTime();
        rw_log_file << i << "th CS Exit by Reader Thread " << id << " at " << exitTime;
        this_thread::sleep_for(chrono::milliseconds((int)exp_distribution(muRem)));
    }
    cout << id << " Reader finished" << endl;
}

// Fair Writer function
void fair_writer(int id) {
    for (int i = 0; i <= kw; i++) {
        auto start = high_resolution_clock::now();
        string reqTime = getSysTime();
        fair_rw_log_file << i << "th CS request by Writer Thread " << id << " at " << reqTime;
        writer_waiting++;
        // Wait until no readers or writers are inside the CS
        sem_wait(&read_write_mutex);
        sem_wait(&writer_inside_mutex);
        while (read_count > 0 || writer_inside) {
            sem_post(&writer_inside_mutex);
            sem_post(&read_write_mutex);
            this_thread::sleep_for(chrono::milliseconds(10)); // Sleep to avoid busy-waiting
            sem_wait(&read_write_mutex);
            sem_wait(&writer_inside_mutex);
        }

        // Now the writer can enter the CS
        writer_inside = true;
        writer_waiting--;
        sem_post(&writer_inside_mutex);

        // Reset writer_waiting when the writer gains access
        sem_post(&read_write_mutex);

        string enterTime = getSysTime();
        fair_rw_log_file << i << "th CS Entry by Writer Thread " << id << " at " << enterTime;

        // Simulate writing in CS
        int muCStime = exp_distribution(muCS);
        this_thread::sleep_for(chrono::milliseconds(muCStime));

        // Exit CS
        sem_wait(&writer_inside_mutex);
        writer_inside = false;
        sem_post(&writer_inside_mutex);

        string exitTime = getSysTime();
        fair_rw_log_file << i << "th CS Exit by Writer Thread " << id << " at " << exitTime;
        auto end = high_resolution_clock::now();
        auto duration = duration_cast<milliseconds>(end - start);
        lock_guard<mutex> lock(fair_writer_entry_mutex);
        fair_writer_entry_times.push_back(duration.count()/1e3);

        // Simulate executing in Remainder Section
        this_thread::sleep_for(chrono::milliseconds((int)exp_distribution(muRem)));
    }
    cout << id << " Writer finished" << endl;
}

// Fair Reader function
void fair_reader(int id) {
    for (int i = 0; i < kr; i++) {
        auto start = high_resolution_clock::now();
        string reqTime = getSysTime();
        fair_rw_log_file << i << "th CS request by Reader Thread " << id << " at " << reqTime;

        // Wait until no writers are waiting or in the critical section
        sem_wait(&read_write_mutex);
        while (writer_inside) {
            sem_post(&read_write_mutex);
            // Sleep for a short duration to avoid busy-waiting
            this_thread::sleep_for(chrono::milliseconds(10));
            sem_wait(&read_write_mutex);
        }
        read_count++;
        sem_post(&read_write_mutex);

        string enterTime = getSysTime();
        fair_rw_log_file << i << "th CS Entry by Reader Thread " << id << " at " << enterTime;

        // Simulate reading from CS
        int muCStime = exp_distribution(muCS);
        this_thread::sleep_for(chrono::milliseconds(muCStime));

        sem_wait(&read_write_mutex);
        read_count--;
        if (read_count == 0)
            sem_post(&rw_mutex);
        sem_post(&read_write_mutex);
        auto end = high_resolution_clock::now();
        auto duration = duration_cast<milliseconds>(end - start);
        lock_guard<mutex> lock(fair_reader_entry_mutex);
        fair_reader_entry_times.push_back(duration.count()/1e3);

        // Simulate executing in Remainder Section
        string exitTime = getSysTime();
        fair_rw_log_file << i << "th CS Exit by Reader Thread " << id << " at " << exitTime;
        this_thread::sleep_for(chrono::milliseconds((int)exp_distribution(muRem)));
    }
    cout << id << " Reader finished" << endl;
}

int main() {
    // Open log files
    rw_log_file.open("RW-log.txt");
    fair_rw_log_file.open("FairRW-log.txt");
    avg_time_file.open("AverageTime.txt");

    // Read input parameters from file
    ifstream infile("inp-params.txt");
    if (!infile) {
        cerr << "Error: Unable to open input file!" << endl;
        return 1;
    }
    infile >> nw >> nr >> kw >> kr >> muCS >> muRem;
    infile.close();

    cout<< "Readers-Writers problem (writer preference):"<<endl;
    // Initialize semaphores
    sem_init(&rw_mutex, 0, 1);
    sem_init(&read_write_mutex, 0, 1);
    sem_init(&writer_inside_mutex, 0, 1);

    // Create writer threads
    vector<thread> writer_threads;
    for (int i = 1; i <= nw; i++) {
        writer_threads.emplace_back(writer, i);
    }
    // Create reader threads
    vector<thread> reader_threads;
    for (int i = 1; i <= nr; i++) {
        reader_threads.emplace_back(reader, i);
    }
    // Join writer threads
    for (auto& thread : writer_threads) {
        thread.join();
    }
    // Join reader threads
    for (auto& thread : reader_threads) {
        thread.join();
    }

    // Calculate and write average times
    double total_writer_time = 0, total_reader_time = 0;
    for (int i = 0; i < writer_entry_times.size(); i++) {
        total_writer_time += writer_entry_times[i];
    }
    for (int i = 0; i < reader_entry_times.size(); i++) {
        total_reader_time += reader_entry_times[i];
    }
    double avg_writer_time = total_writer_time / writer_entry_times.size();
    double avg_reader_time = total_reader_time / reader_entry_times.size();

    avg_time_file << "For Readers-Writers problem (writer preference):"<< endl;
    avg_time_file << "Average time for Writer Thread to gain entry to CS: " << avg_writer_time << " seconds" << endl;
    avg_time_file << "Average time for Reader Thread to gain entry to CS: " << avg_reader_time << " seconds" << endl; 

    cout<< "\nFair Readers-Writers problem :"<<endl;
    read_count = 0;
    writer_waiting = 0;
    writer_inside = false;

    // Create writer threads
    vector<thread> fair_writer_threads;
    for (int i = 1; i <= nw; i++) {
        fair_writer_threads.emplace_back(fair_writer, i);
    }

    // Create reader threads
    vector<thread> fair_reader_threads;
    for (int i = 1; i <= nr; i++) {
        fair_reader_threads.emplace_back(fair_reader, i);
    }

    // Join writer threads
    for (auto& thread : fair_writer_threads) {
        thread.join();
    }

    // Join reader threads
    for (auto& thread : fair_reader_threads) {
        thread.join();
    }
    // Calculate and write average times
    double fair_total_writer_time = 0, fair_total_reader_time = 0;
    for (int i = 0; i < fair_writer_entry_times.size(); i++) {
        fair_total_writer_time += fair_writer_entry_times[i];
    }
    for (int i = 0; i < reader_entry_times.size(); i++) {
        fair_total_reader_time += fair_reader_entry_times[i];
    }
    double fair_avg_writer_time = fair_total_writer_time / fair_writer_entry_times.size();
    double fair_avg_reader_time = fair_total_reader_time / fair_reader_entry_times.size();
    
    avg_time_file << "For Fair Readers-Writers problem :"<< endl;
    avg_time_file << "Average time for Writer Thread to gain entry to CS: " << fair_avg_writer_time << " seconds" << endl;
    avg_time_file << "Average time for Reader Thread to gain entry to CS: " << fair_avg_reader_time << " seconds" << endl;
    
    // Close log files
    rw_log_file.close();
    fair_rw_log_file.close();
    avg_time_file.close();

    // Destroy semaphores
    sem_destroy(&rw_mutex);
    sem_destroy(&read_write_mutex);
    sem_destroy(&writer_inside_mutex);

    return 0;
}
